package com.example.eds_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
